import React from "react";
import { Link } from "react-router-dom";
import "./css/sidebar.css";

const Sidebar = () => (
  <>
    <div className="sidebar">
      <div className="profile-section">
        <div className="profile-pic">
          <img src="/public/profile.png" alt="Profile" className="profile-img" />
        </div>
      </div>
      <nav>
        <hr className="profile-divider" />
        <ul>
          <li><Link to="/dashboard" className="sidebar-button">Home</Link></li>
          <li><Link to="/smart-qna" className="sidebar-button">Smart Q&A</Link></li>
          <li><Link to="/progress-tracking" className="sidebar-button">Progress</Link></li>
          <li><Link to="/topics-and-subjects" className="sidebar-button">Topics & Subjects</Link></li>
        </ul>
      </nav>
    </div>

    <div className="profile-section-container">
      <div className="vertical-line"></div>
    </div>
  </>
);

export default Sidebar;




