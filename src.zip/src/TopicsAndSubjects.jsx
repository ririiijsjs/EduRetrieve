import React from "react";
import { Link } from "react-router-dom";
import "./css/TopicsAndSubjects.css";

function Navigation() {
  return (
    <nav>
      <Link to="/">Login</Link>
      <Link to="/signup">Sign Up</Link>
      <Link to="/dashboard">Dashboard</Link>
    </nav>
  );
}

const TopicsAndSubjects = () => {
  return (
    <div className="container">
      <aside className="sidebars">
        <div className="avatar-section"></div>
         <div className="avatar"></div>
          <img src="/public/profile.png" alt="Profile" className="profile-img"/>
          <hr className="avatar-divider" />
        <nav className="menu">
          <button>Home</button>
          <button>Smart Q&A</button>
          <button>Progress</button>
          <button>Topics & Subjects</button>
        </nav>
        <div className="back-arrow">←</div>
      </aside>

      <div className="profile-section-container">
       <div className="vertical-line"></div>
      </div>


      <main className="content">
        <h1>Organized Storage for Topics & Subjects</h1>
        <hr className="title-divider" />

        <div className="progress-card">
        <h2 className="card-title">Your Learning Progress</h2>
         <p>Save and organize your courses and topics for easy access anytime.</p>
        </div>

        <div className="grid-section">
  <h3>Saved Courses</h3>
  <div className="grid">
    <div className="cardbox">
      <div className="plus">+</div>
      <p>Save a Course</p>
    </div>
    <div className="cardbox">
      <div className="plus">+</div>
      <p>Save a Course</p>
    </div>
    <div className="cardbox">
      <div className="plus">+</div>
      <p>Save a Course</p>
    </div>
    <div className="cardbox outlined">
      <div className="plus">+</div>
      <p>Save a Course</p>
    </div>
  </div>
</div>

      </main>
    </div>
  );
};

export default TopicsAndSubjects;
