import React from "react";
import { FaSearch } from "react-icons/fa";
import "./css/SmartQnA.css";

const SmartQnA = () => {
  return (
    <div className="smartqna-container">
      <div className="sidebar">
        <div className="profile-section">
          <div className="profile-pic">
             <img src="/public/profile.png" alt="Profile" className="profile-img"/>
            </div>
        </div>
        <hr className="profile-divider" />
        <button className="sidebar-button">Home</button>
        <button className="sidebar-button">Smart Q&A</button>
        <button className="sidebar-button">Progress</button>
        <button className="sidebar-button">Topics & Subjects</button>
      </div>

      <div className="profile-section-container">
       <div className="vertical-line"></div>
      </div>

      <div className="chat-section">
        <div className="chat-header">Chats</div>
        <div className="chat-search">
          <input
            type="text"
            placeholder="Search..."
            className="chat-input"
          />
          <button className="search-icon">
            <FaSearch />
          </button>
        </div>
        <div className="chat-list">
          <p className="chat-label">Today</p>
          <ChatItem title="Travel Plan" time="1m" />
          <ChatItem title="Cooking Recipes Ideas" time="10m" />
          <ChatItem title="Sorting Algorithms" time="20m" />
          <ChatItem title="What is Database" time="30m" />
          <p className="chat-label">Yesterday</p>
          <ChatItem title="Cooking Recipes Idea" time="3/11" />
          <ChatItem title="Travel Plan" time="3/11" />
          <p className="chat-label">Previous 7 Days</p>
          <ChatItem title="Cooking Recipes Idea" time="3/5" />
        </div>
      </div>

      <div className="main-section">
        <div>
          <h1 className="main-title">Smart Q&A</h1>
          <hr className="divider" />
        </div>
        <div className="welcome-box">
          <p className="emoji">🤖</p>
          <p className="welcome-text">
            Welcome to EduRetrieve!<br />Ready to explore knowledge?
          </p>
        </div>
        <div className="input-box">
          <input
            type="text"
            placeholder="Ask me anything..."
            className="question-input"
          />
          <button className="submit-button">↑</button>
        </div>
      </div>
    </div>
  );
};

const ChatItem = ({ title, time }) => (
  <div className="chat-item">
    <p className="chat-title">{title}</p>
    <p className="chat-snippet">Hello! I'd be happy to.. {time}</p>
  </div>
);

export default SmartQnA;