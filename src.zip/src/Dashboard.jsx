import React from "react";
import "./css/Dashboard.css";

const Dashboard = () => {
  return (
    <div className="dashboard">
      <div className="sidebar">
      <div className="profile-section">
        <div className="profile-pic" />
        <img src="/public/profile.png" alt="Profile" className="profile-img"/>
        </div>
      <div>
        <hr className="profile-divider" />   
        <ul className="nav-links">
          <li>Home</li>
          <li>Smart Q&A</li>
          <li>Progress</li>
          <li>Topics & Subjects</li>
        </ul>
      </div>
     </div>
      
      <div className="profile-section-container">
       <div className="vertical-line"></div>
      </div>

      <div className="main-content">
        <h1>Home</h1>
        <div className="card welcome">
          <div className="left">
            <h2>Welcome Back!</h2>
            <p>How can I assist you today?</p>
            <button>Start Asking</button>
          </div>
          <div className="right">
            <img src="public/robot.png" alt="Robot" className="robot-img"/> 
          </div>
        </div>

        <div className="card updates">
          <h2>Real-Time Updates <span role="img" aria-label="bell">🔔</span></h2>
          <div className="section">
            <h4 className="today">Today</h4>
            <ul>
              <li><strong>New Course Available:</strong> Mastering Python Data Structures <br /><a href="#">View Course</a> • 10:30AM</li>
              <li><strong>AI Recommendation:</strong> Build a To-Do App with React.js – Hands-on Project <br /><a href="#">Start Project</a> • 9:45AM</li>
              <li><strong>Security Alert:</strong> Update Your Password for Enhanced Security <br /><a href="#">Update Now</a> • 8:30AM</li>
              <li><strong>New Course Available:</strong> Introduction to Cloud Computing with AWS <br /><a href="#">View Course</a> • 4:15PM</li>
            </ul>
          </div>

          <div className="section">
            <h4 className="yesterday">Yesterday</h4>
            <ul>
              <li><strong>New Guide:</strong> Backend Development with Node.js & Express.js <br /><a href="#">Read Guide</a> • 5:50PM</li>
              <li><strong>Cybersecurity Basics:</strong> Protecting Your Code from Vulnerabilities <br /><a href="#">Learn More</a> • 3:20PM</li>
              <li><strong>New Course Available:</strong> Advanced Algorithms and Data Structures</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
