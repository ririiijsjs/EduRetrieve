import React from "react";
import "./css/ProgressTracking.css";

const ProgressTracking = () => {
  return (
    <div className="progress-page">
      <div className="sidebar">
       <div className="profile-section">
        <div className="profile-pic" />
        <img src="/public/profile.png" alt="Profile" className="profile-img"/>
        </div>
        <div>
        <hr className="profile-divider" />
        <ul className="nav-links">
          <li>Home</li>
          <li>Smart Q&A</li>
          <li>Progress</li>
          <li>Topics & Subjects</li>
        </ul>
      </div>
     </div>

     <div className="profile-section-container">
       <div className="vertical-line"></div>
      </div>

      <div className="main-content">
        <h1>Progress Tracking</h1>
        <hr className="title-divider" />

        <div className="progress-card">
          <h2 className="card-title">Your Learning Progress</h2>

          <div className="stats">
            <div className="stat-box blue">
              <span>Total Study Hours This Week</span> 12h 30m studied this week
            </div>
            <div className="stat-box purple">
              <span>Topics Completed</span> 65% of total topics finished
            </div>
            <div className="stat-box sky">
              <span>Pending Topics</span> 35% topics remaining
            </div>
            <div className="stat-box teal">
              <span>Average Daily Study Time</span> 2h 5m per day
            </div>
          </div>

          <hr className="card-divider" />

          <div className="details">
            <p><strong className="blue-text">Study Hours Completed</strong><br />You have studied 12 hours 30 minutes this week.</p>
            <p><strong className="blue-text">Topics Completed</strong><br />You have completed 65% of total topics.</p>
            <p><strong className="blue-text">Pending Topics</strong><br />You have 35% of topics remaining.</p>
            <p><strong className="blue-text">Average Daily Study Time</strong><br />Your average daily study time is 2 hours 5 minutes per day.</p>
            <p><strong className="blue-text">Next Recommended Action</strong><br />You're close to finishing Module X. Would you like to continue?<br />Try setting a study goal for next week to stay on track.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgressTracking;
